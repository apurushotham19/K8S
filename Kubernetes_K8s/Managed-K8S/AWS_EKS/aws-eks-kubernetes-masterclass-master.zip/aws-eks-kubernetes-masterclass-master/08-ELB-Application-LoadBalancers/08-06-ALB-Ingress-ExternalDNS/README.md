# External DNS 

1. Deploy External DNS
2. Use External DNS for our Application


## External DNS References
- https://github.com/kubernetes-sigs/external-dns/blob/master/docs/tutorials/alb-ingress.md
- https://github.com/kubernetes-sigs/external-dns/blob/master/docs/tutorials/aws.md


